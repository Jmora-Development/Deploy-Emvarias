﻿window.routehFileDownload = {
    downloadFromBase64: function (
        fileName,
        contentType,
        base64Content) {

        if (!base64Content) {
            throw new Error(
                "El contenido del archivo está vacío.");
        }

        const byteCharacters =
            atob(base64Content);

        const byteNumbers =
            new Array(byteCharacters.length);

        for (let index = 0;
            index < byteCharacters.length;
            index++) {

            byteNumbers[index] =
                byteCharacters.charCodeAt(index);
        }

        const byteArray =
            new Uint8Array(byteNumbers);

        const blob =
            new Blob(
                [byteArray],
                {
                    type:
                        contentType ||
                        "application/octet-stream"
                });

        const objectUrl =
            URL.createObjectURL(blob);

        const link =
            document.createElement("a");

        link.href =
            objectUrl;

        link.download =
            fileName ||
            "archivo.pdf";

        link.style.display =
            "none";

        document.body.appendChild(link);

        link.click();

        document.body.removeChild(link);

        URL.revokeObjectURL(objectUrl);
    }
};