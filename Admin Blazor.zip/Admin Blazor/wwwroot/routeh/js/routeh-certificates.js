﻿window.routehCertificates = {

    downloadBase64File: function (
        fileName,
        contentType,
        base64Content) {

        if (!base64Content) {
            console.error("El contenido del archivo está vacío.");
            return;
        }

        try {

            const binary = atob(base64Content);

            const bytes = new Uint8Array(binary.length);

            for (let i = 0; i < binary.length; i++) {
                bytes[i] = binary.charCodeAt(i);
            }

            const blob = new Blob(
                [bytes],
                {
                    type: contentType || "application/pdf"
                });

            const url = URL.createObjectURL(blob);

            const anchor = document.createElement("a");

            anchor.href = url;
            anchor.download = fileName || "documento.pdf";

            document.body.appendChild(anchor);

            anchor.click();

            anchor.remove();

            URL.revokeObjectURL(url);
        }
        catch (error) {
            console.error(
                "Error descargando el archivo.",
                error);
        }
    }
};